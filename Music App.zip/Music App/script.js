const music = new Audio('vande.mp3')

const songs = [
    { 
        id:"1",
        songName:"On My Way"
        <div class ="subtitle">Alan Walker</div>,
        poster: ""
    }
]